

<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-md-12 grid-margin">
    <div class="d-flex justify-content-between flex-wrap">
      <div class="d-flex align-items-end flex-wrap">
        <div class="mr-md-3 mr-xl-5">
          <h2>Welcome back,</h2>
          <p class="mb-md-0">Your Dashboard.</p>
        </div>
        
        
      </div>
      
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Ravi\Documents\PHP\medical-abbreviations\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>