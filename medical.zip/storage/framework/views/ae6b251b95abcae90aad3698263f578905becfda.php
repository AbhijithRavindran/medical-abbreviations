
<?php $__env->startSection('content'); ?>
    <div class="col-md-6 offset-lg-2 grid-margin stretch-card text-center">
        <div class="card">
          <div class="card-body">
            <h2 ><?php echo e($abbreviation->abbreviation); ?></h2>
            <p class="card-description">
                Description:&nbsp;<?php echo e($abbreviation->description); ?>

            </p>
            <p>
                <?php echo e($abbreviation->definition); ?>

            </p>
          </div>
        </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Ravi\Documents\PHP\medical-abbreviations\resources\views/view_abbreviation.blade.php ENDPATH**/ ?>