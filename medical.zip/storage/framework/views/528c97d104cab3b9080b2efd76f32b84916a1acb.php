
<?php $__env->startSection('content'); ?>
        <div class="col-md-6 offset-lg-1 grid-margin grid-margin-md-0 stretch-card">
            <div class="card">
              <div class="card-body">
              <h4 class="card-title">Abbreviations</h4>
                <p class="card-description"></p>
                <form action="/filter" method="post">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                  <label for="exampleFormControlSelect3">Sort By </label>
                  <select name="category_id" class="form-control form-control-sm" id="exampleFormControlSelect3" required>
                    <option value="0">All</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                  <br>
                  <button type="submit" class="btn btn-primary mr-2">Sort</button>
                </div>
                
              </form>
                <ul class="list-arrow">
                  <?php $__currentLoopData = $abbreviations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $abbreviation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><a href="/abbreviation/<?php echo e($abbreviation->id); ?>"><?php echo e($abbreviation->abbreviation); ?></a></li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
              </div>
            </div>
          </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Ravi\Documents\PHP\medical-abbreviations\resources\views/abbreviations.blade.php ENDPATH**/ ?>