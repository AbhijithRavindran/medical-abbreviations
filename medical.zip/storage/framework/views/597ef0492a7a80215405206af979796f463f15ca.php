
<?php $__env->startSection('content'); ?>
        <div class="col-md-6 offset-lg-2 grid-margin grid-margin-md-0 stretch-card">
            <div class="card">
              <div class="card-body">
                <h4 class="card-title"><?php echo e($main_category->name); ?></h4>
                <p class="card-description"></p>
                <ul class="list-arrow">
                  <?php $__currentLoopData = $sub_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><a href="/sub_category/<?php echo e($sub_category->id); ?>"><?php echo e($sub_category->name); ?></a></li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
              </div>
            </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Ravi\Documents\PHP\medical-abbreviations\resources\views/sub_categories.blade.php ENDPATH**/ ?>