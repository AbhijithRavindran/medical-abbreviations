
<?php $__env->startSection('content'); ?>
<div class="col-12 grid-margin stretch-card">
    <div class="card">
      <div class="card-body">
        <h4 class="card-title">ADD NEW AABREVIATION</h4>
        <p class="card-description">
            Create new abbreviations for specific sub-categories. Main category will automatically be assigned.
        </p>
        <form class="forms-sample" action="/admin/abbreviation/create" method="post">
          <?php echo csrf_field(); ?>
          <div class="form-group">
            <label for="exampleInputName1">Abbreviation</label>
            <input type="text" required name="abbreviation" class="form-control" id="exampleInputName1" placeholder="abbreviation..">
          </div>
          <div class="form-group">
            <label for="exampleInputName1">Description</label>
            <input type="text" required name="description" class="form-control" id="exampleInputName1" placeholder="description..">
          </div>
          <div class="form-group">
            <label for="exampleSelectGender">Sub-Category</label>
              <select class="form-control" id="exampleSelectGender" name="sub_category_id">
                <?php $__currentLoopData = $sub_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($sub_category->id); ?>"><?php echo e($sub_category->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
          <div class="form-group">
            <label for="exampleTextarea1">Definition</label>
            <textarea required name="definition" class="form-control" id="exampleTextarea1" rows="4"></textarea>
          </div>
          <button type="submit" class="btn btn-primary mr-2">Submit</button>
          <a href="/admin/abbreviations" class="btn btn-light">Cancel</a>
        </form>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Ravi\Documents\PHP\medical-abbreviations\resources\views/admin/new_abbreviation.blade.php ENDPATH**/ ?>