
<?php $__env->startSection('content'); ?>


<div class="row">
  <div class="col-md-12 grid-margin">
    <div class="d-flex justify-content-between flex-wrap">
      <div class="d-flex align-items-end flex-wrap">
        <div class="mr-md-3 mr-xl-5">
          <h2>Abbreviations</h2>
          <p class="mb-md-0">You can add , edit and delete abbreviations here.</p>
        </div>
        
      </div>
      <div class="d-flex justify-content-between align-items-end flex-wrap">
        
        <a href="/admin/abbreviation/new" class="btn btn-primary mt-2 mt-xl-0">Create Abbreviation</a>
      </div>
    </div>
  </div>
</div>
<div class="row">
  <div class="col-md-12 stretch-card">
    <div class="card">
      <div class="card-body">
        <p class="card-title">Abbreviation List</p>
        <div class="table-responsive">
          <table id="recent-purchases-listing" class="table">
            <thead>
              <tr>
                  <th>Name</th>
                  <th>Description</th>
                  <th>Actions</th>
              </tr>
            </thead>
            <tbody>

              <?php $__currentLoopData = $abbreviations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $abbreviation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                  <td><?php echo e($abbreviation->abbreviation); ?></td>
                  <td><?php echo e($abbreviation->description); ?></td>
                  <td>
                      <a href="/admin/view_abbreviation/<?php echo e($abbreviation->id); ?>" class="btn btn-primary btn-rounded btn-fw">Show</a>

                  </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
            </tbody>
          </table>
          <?php echo $abbreviations->links(); ?>

        </div>
      </div>
    </div>
  </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Ravi\Documents\PHP\medical-abbreviations\resources\views/admin/abbreviations.blade.php ENDPATH**/ ?>