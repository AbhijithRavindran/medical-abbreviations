
<?php $__env->startSection('content'); ?>
<div class="col-12 grid-margin stretch-card">
    <div class="card">
      <div class="card-body">
      <h4 class="card-title">AABREVIATION ID# <?php echo e($abbreviation->id); ?></h4>
        <p class="card-description">
            Update or delete the abbreviation here.
        </p>
    <form class="forms-sample" action="/admin/update_abbreviation/<?php echo e($abbreviation->id); ?>" method="POST" >
        <?php echo csrf_field(); ?>
        <?php echo method_field('PATCH'); ?>
          <div class="form-group">
            <label for="exampleInputName1">Abbreviation</label>
          <input type="text" value="<?php echo e($abbreviation->abbreviation); ?>"  name="abbreviation" class="form-control" id="exampleInputName1" placeholder="abbreviation..">
          </div>
          <div class="form-group">
            <label for="exampleInputName1">Description</label>
            <input type="text" value="<?php echo e($abbreviation->description); ?>" name="description" class="form-control" id="exampleInputName1" placeholder="description..">
          </div>
          <div class="form-group">
            <label for="exampleSelectGender">Sub-Category</label>
              <select class="form-control" id="exampleSelectGender" name="sub_category_id">
                <?php $__currentLoopData = $sub_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(($category->id)==($sub_category->id)): ?>
                        <option selected value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                    <?php else: ?>
                        <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
          </div>
          <div class="form-group">
            <label for="exampleTextarea1">Definition</label>
            <textarea class="form-control" name="definition" id="exampleTextarea1" rows="4"><?php echo e($abbreviation->definition); ?></textarea>
          </div>
          <button type="submit" class="btn btn-warning mr-2">Update</button>
          <a href="/admin/delete_abbreviation/<?php echo e($abbreviation->id); ?>" class="btn btn-danger mr-2">Delete</a>
          <a href="/admin/abbreviations" class="btn btn-light">Cancel</a>
        </form>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Ravi\Documents\PHP\medical-abbreviations\resources\views/admin/view_abbreviation.blade.php ENDPATH**/ ?>