
<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-md-12 grid-margin">
    <div class="d-flex justify-content-between flex-wrap">
      <div class="d-flex align-items-end flex-wrap">
        <div class="mr-md-3 mr-xl-5">
          <h2>Sub-Categories</h2>
          <p class="mb-md-0">You can add sub-categories here.</p>
        </div>
      </div>
      
    </div>
  </div>
</div>

<div class="row">
  <div class="col-md-4 grid-margin stretch-card">
    <div class="card">
      <div class="card-body">
      <h4 class="card-title">Add new Sub-category for <br><b><?php echo e($main_category->name); ?></b></h4>
        <p class="card-description">
          Add a new sub category here.
        </p>
        <form action="/admin/sub_categories/create/<?php echo e($main_category->id); ?>" method="POST"  class="forms-sample">
          <?php echo csrf_field(); ?>
        <div class="form-group">
          <div class="input-group">
              <input type="text" name="name" class="form-control" placeholder="Sub - category name" aria-label="">
              <div class="input-group-append">
                <button class="btn btn-sm btn-success" type="submit">Add</button>
              </div>
            
          </div>
        </div>
      </form>
      </div>
    </div>
  </div>
</div>

<br>
<div class="row">
  <div class="col-md-12 stretch-card">
    <div class="card">
      <div class="card-body">
        <p class="card-title">Sub Categories List for <b><?php echo e($main_category->name); ?></b></p>
        <div class="table-responsive">
          <table id="recent-purchases-listing" class="table">
            <thead>
              <tr>
                  <th>Name</th>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $sub_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($sub_category->name); ?></td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
          <?php echo $sub_categories->links(); ?>

        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Ravi\Documents\PHP\medical-abbreviations\resources\views/admin/sub_categories.blade.php ENDPATH**/ ?>